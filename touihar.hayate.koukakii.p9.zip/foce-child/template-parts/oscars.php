<section class="oscar">
    <div>
        <h3 class="oscar__nomination-text">Fleurs d’oranger & chats errants <br>
            est nominé aux Oscars Short  <br>
            Film Animated de 2022 !
        </h3>
    </div>
    <img class="oscar__nomination-img" src="<?php echo  get_stylesheet_directory_uri() . '/assets/images/oscar.png'; ?>" alt="nomination">
</section>
